package com.gama333.ups.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gama333.ups.model.Persona;


public interface IPersonaRepo extends JpaRepository<Persona, Integer>{
	
}
