package com.gama333.ups.controller;

import java.util.List;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gama333.ups.model.Persona;
import com.gama333.ups.repo.IPersonaRepo;

@RestController
@RequestMapping("/personas")
public class SqlController {

	@Autowired
	private IPersonaRepo repo;
	private static Logger LOGGER = LoggerFactory.getLogger(SqlController.class);
	
	private final ExecutorService executor = Executors.newFixedThreadPool(5);
	List<Persona> listaAll = null;
	
	
	@GetMapping
	public List<Persona> listar(){
		
		CompletableFuture<String> futureAsync = CompletableFuture.supplyAsync(() -> {
		    LOGGER.info("Comenzando supplyAsync with exception...");
//		    Sleep.sleepSeconds(2);
		    
		    listaAll = repo.findAll();
		    
		    LOGGER.info("Terminado supplyAsync with exception!");
		    throw new RuntimeException("Error en el futuro");
		}, executor);
		 
		CompletableFuture<String> futureEx = futureAsync.exceptionally(e -> {
		    LOGGER.error("Resultado con excepción!!", e);
		    return "StringPorDefecto";
		});
		 
		futureEx.whenCompleteAsync((s, e) -> LOGGER.info("Resultado futureEx: {}", s),
		        executor);
		
		return listaAll;
	}

	@PostMapping
	public void insertar(@RequestBody Persona per){
		repo.save(per);
	}
	
	@PutMapping
	public void modificar(@RequestBody Persona per){
		repo.save(per);
	}
	
	@DeleteMapping(value = "/{id}")
	public void eliminar(@PathVariable("id") Integer id) {
		repo.deleteById(id);
	}
}
