package com.gama333.ups.repo;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.gama333.ups.model.Persona;


public interface IPersonaRepoMongo extends MongoRepository<Persona, String> {

    public Persona findByIdPersona(String nombre);
    public List<Persona> findByNombre(String nombre);
    
}
